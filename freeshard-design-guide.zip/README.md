---
type: reference
first_mentioned: 2026-05-29
---

# Freeshard web-terminal UI style — "Daylight Instrument"

This folder is the home of the Freeshard **web-terminal** visual style: a calm, honest,
precise interface in the Nordic-functionalist tradition. It serves three audiences.

| You want to… | Read / use |
|---|---|
| **Understand & reason about the style** (human) | [`design-guide.md`](design-guide.md) — narrative source of truth · [`design-guide.pdf`](design-guide.pdf) — rendered visual guide |
| **Apply the style** (agent: exact values, CSS) | [`tokens/tokens.css`](tokens/tokens.css) · [`tokens/tokens.json`](tokens/tokens.json) · [`tokens/components.css`](tokens/components.css) |
| **Reason, modify, extend** (agent) | [`design-guide.md`](design-guide.md) + [`DECISIONS.md`](DECISIONS.md) (why things are the way they are) + [`build/`](build/) (regenerate the PDF) |

## File map

```
README.md           — this file: context + index + how to rebuild
design-guide.md      — the style guide as prose (source of truth)
design-guide.pdf     — the style guide rendered for humans (11 pp)
DECISIONS.md         — decision log: choices, rejected options, parked ideas, rationale
tokens/
  tokens.json        — canonical machine-readable values (color, type, space, radius, glow…)
  tokens.css         — CSS custom properties, light + [data-theme=dark]
  components.css      — copy-paste component recipes built on the tokens
build/
  build_guide.py     — generates guide.html from the tokens + component demos
  build_modals.py    — playground: modal-backgrounding approaches preview (writes build/modals.html)
  build_menus.py     — playground: context-menu look proposals + beak/edge behaviour (writes build/menus.html)
  build_sparkline.py — playground: sparkline variants (gradient tips, compact form) (writes build/sparkline.html)
  build_keynav.py    — playground: keyboard-nav chrome (focus ring + zoom, Alt-hold hint badges) (writes build/keynav.html)
  guide.html         — generated artifact (input to the PDF render)
  shard.png          — logomark asset used by the build
tools/
  preview-server.py  — secret-gated static server to preview the folder over the network
  .secret            — shared secret for the preview server (not for distribution)
```

## Canonical values & sync rule

`tokens.json` is the canonical data. `tokens.css` mirrors it for direct use, and
`build/build_guide.py` embeds the same values for rendering. **When you change a value,
update all three** (json → css → build script) so the docs and the guide never drift.

## Rebuild the PDF

```bash
cd build
python3 build_guide.py                 # writes build/guide.html
chromium --headless=new --no-sandbox --disable-gpu --virtual-time-budget=8000 \
  --no-pdf-header-footer \
  --print-to-pdf=../design-guide.pdf "file://$PWD/guide.html"
```

Notes: Chromium is the snap build (`/snap/bin/chromium`); the dbus/AppArmor warnings it
prints are harmless. Fonts (Inter, IBM Plex Mono) load from Google Fonts at render time, so
the render needs network. `--virtual-time-budget` gives fonts time to load. Background
colors are forced on via `print-color-adjust: exact` in the HTML.

## Preview over the network (optional)

```bash
cd tools && PORT=8088 python3 preview-server.py
```

Serves this folder on `0.0.0.0:8088`, gated by `?key=<.secret>` for HTML; static assets
(`.pdf`, `.png`, …) are ungated. e.g. `http://<host>:8088/design-guide.pdf`. No timeout.

## Scope & relationships

- Scope is the **web-terminal** (the daily-driver shard UI), not the controller dashboard,
  landing page, or docs — though the language could extend there later.
- Distinct from [[visual-style]] (blog cover *illustration*, ligne claire). They share only
  the brand palette.
- Project context: [[project-overview]].
